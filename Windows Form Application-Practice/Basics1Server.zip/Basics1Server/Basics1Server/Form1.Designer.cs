﻿namespace Basics1Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnWindow1 = new System.Windows.Forms.Button();
            this.btnWindow2 = new System.Windows.Forms.Button();
            this.btnWindow3 = new System.Windows.Forms.Button();
            this.Window1 = new System.Windows.Forms.PictureBox();
            this.Window2 = new System.Windows.Forms.PictureBox();
            this.Window3 = new System.Windows.Forms.PictureBox();
            this.btnSubWindow1 = new System.Windows.Forms.Button();
            this.btnSubWindow2 = new System.Windows.Forms.Button();
            this.SubWindow1 = new System.Windows.Forms.PictureBox();
            this.SubWindow2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Window1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Window2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Window3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SubWindow1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SubWindow2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnWindow1
            // 
            this.btnWindow1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnWindow1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWindow1.Location = new System.Drawing.Point(14, 12);
            this.btnWindow1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnWindow1.Name = "btnWindow1";
            this.btnWindow1.Size = new System.Drawing.Size(111, 52);
            this.btnWindow1.TabIndex = 0;
            this.btnWindow1.Text = "Window1";
            this.btnWindow1.UseVisualStyleBackColor = false;
            this.btnWindow1.Click += new System.EventHandler(this.btnWindow1_Click);
            // 
            // btnWindow2
            // 
            this.btnWindow2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnWindow2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWindow2.Location = new System.Drawing.Point(14, 60);
            this.btnWindow2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnWindow2.Name = "btnWindow2";
            this.btnWindow2.Size = new System.Drawing.Size(111, 52);
            this.btnWindow2.TabIndex = 1;
            this.btnWindow2.Text = "Window2";
            this.btnWindow2.UseVisualStyleBackColor = false;
            this.btnWindow2.Click += new System.EventHandler(this.btnWindow2_Click);
            // 
            // btnWindow3
            // 
            this.btnWindow3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnWindow3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWindow3.Location = new System.Drawing.Point(14, 108);
            this.btnWindow3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnWindow3.Name = "btnWindow3";
            this.btnWindow3.Size = new System.Drawing.Size(111, 52);
            this.btnWindow3.TabIndex = 2;
            this.btnWindow3.Text = "Window3";
            this.btnWindow3.UseVisualStyleBackColor = false;
            this.btnWindow3.Click += new System.EventHandler(this.btnWindow3_Click);
            // 
            // Window1
            // 
            this.Window1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Window1.Location = new System.Drawing.Point(123, 14);
            this.Window1.Name = "Window1";
            this.Window1.Size = new System.Drawing.Size(737, 426);
            this.Window1.TabIndex = 3;
            this.Window1.TabStop = false;
            // 
            // Window2
            // 
            this.Window2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Window2.Location = new System.Drawing.Point(123, 14);
            this.Window2.Name = "Window2";
            this.Window2.Size = new System.Drawing.Size(737, 426);
            this.Window2.TabIndex = 4;
            this.Window2.TabStop = false;
            this.Window2.Click += new System.EventHandler(this.Window2_Click);
            // 
            // Window3
            // 
            this.Window3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Window3.Location = new System.Drawing.Point(123, 14);
            this.Window3.Name = "Window3";
            this.Window3.Size = new System.Drawing.Size(737, 426);
            this.Window3.TabIndex = 5;
            this.Window3.TabStop = false;
            this.Window3.Visible = false;
            // 
            // btnSubWindow1
            // 
            this.btnSubWindow1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSubWindow1.Location = new System.Drawing.Point(721, 13);
            this.btnSubWindow1.Name = "btnSubWindow1";
            this.btnSubWindow1.Size = new System.Drawing.Size(111, 50);
            this.btnSubWindow1.TabIndex = 6;
            this.btnSubWindow1.Text = "SubWindow1";
            this.btnSubWindow1.UseVisualStyleBackColor = false;
            this.btnSubWindow1.Click += new System.EventHandler(this.btnSubWindow1_Click);
            // 
            // btnSubWindow2
            // 
            this.btnSubWindow2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSubWindow2.Location = new System.Drawing.Point(614, 14);
            this.btnSubWindow2.Name = "btnSubWindow2";
            this.btnSubWindow2.Size = new System.Drawing.Size(111, 50);
            this.btnSubWindow2.TabIndex = 7;
            this.btnSubWindow2.Text = "SubWindow2";
            this.btnSubWindow2.UseVisualStyleBackColor = false;
            this.btnSubWindow2.Click += new System.EventHandler(this.btnSubWindow2_Click);
            // 
            // SubWindow1
            // 
            this.SubWindow1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.SubWindow1.Location = new System.Drawing.Point(123, 60);
            this.SubWindow1.Name = "SubWindow1";
            this.SubWindow1.Size = new System.Drawing.Size(737, 380);
            this.SubWindow1.TabIndex = 8;
            this.SubWindow1.TabStop = false;
            // 
            // SubWindow2
            // 
            this.SubWindow2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.SubWindow2.Location = new System.Drawing.Point(123, 60);
            this.SubWindow2.Name = "SubWindow2";
            this.SubWindow2.Size = new System.Drawing.Size(737, 380);
            this.SubWindow2.TabIndex = 9;
            this.SubWindow2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 452);
            this.Controls.Add(this.SubWindow1);
            this.Controls.Add(this.btnSubWindow2);
            this.Controls.Add(this.btnSubWindow1);
            this.Controls.Add(this.Window1);
            this.Controls.Add(this.btnWindow3);
            this.Controls.Add(this.btnWindow2);
            this.Controls.Add(this.btnWindow1);
            this.Controls.Add(this.Window3);
            this.Controls.Add(this.Window2);
            this.Controls.Add(this.SubWindow2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Window1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Window2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Window3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SubWindow1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SubWindow2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnWindow1;
        private System.Windows.Forms.Button btnWindow2;
        private System.Windows.Forms.Button btnWindow3;
        private System.Windows.Forms.PictureBox Window1;
        private System.Windows.Forms.PictureBox Window2;
        private System.Windows.Forms.PictureBox Window3;
        private System.Windows.Forms.Button btnSubWindow1;
        private System.Windows.Forms.Button btnSubWindow2;
        private System.Windows.Forms.PictureBox SubWindow1;
        private System.Windows.Forms.PictureBox SubWindow2;
    }
}

